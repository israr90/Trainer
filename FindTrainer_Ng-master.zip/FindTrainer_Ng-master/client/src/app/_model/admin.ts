export interface Admin {
}
