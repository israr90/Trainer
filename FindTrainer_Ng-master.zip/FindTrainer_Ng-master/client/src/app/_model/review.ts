export interface IReview {
  senderId: string;
  stars: number;
  created: Date;
  content: string;
}
