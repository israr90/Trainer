import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { USERS } from '../constants/collections';
import { Trainer, UserClass } from '../_model/user';
@Injectable({
  providedIn: 'root',
})
export class UserServiceService {
  constructor(private db: AngularFirestore) {}
  getUsers() {
    return this.db.collection(USERS).valueChanges();
  }
  addUser(id: string, user: UserClass) {
    return this.db.collection(USERS).doc(id).set(user);
  }
  addTrainer(id: string, trainer: Trainer) {
    return this.db.collection(USERS).doc(id).set(trainer);
  }
}
