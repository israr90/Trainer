export const REVIEWS = 'reviews';
export const USERS = 'users';
