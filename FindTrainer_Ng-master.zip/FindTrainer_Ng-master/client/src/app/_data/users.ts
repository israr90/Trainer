import { UserClass } from '../_model/user';

export const usersData = [
  new UserClass(1, 'eric', 'eric'),
  new UserClass(1, 'kevin', 'kevin'),
  new UserClass(2, 'tim', 'tim'),
  new UserClass(0, 'sam', 'sam'),
  new UserClass(0, 'kelly', 'kelly'),
  new UserClass(2, 'rick', 'rick2'),
  new UserClass(2, 'timmy', 'tim2'),
];
